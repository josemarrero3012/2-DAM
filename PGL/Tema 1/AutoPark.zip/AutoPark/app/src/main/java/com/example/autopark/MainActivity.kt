package com.example.autopark

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etConductor = findViewById<EditText>(R.id.etConductor)
        val etHoras = findViewById<EditText>(R.id.etHoras)
        val btnReservar = findViewById<Button>(R.id.btnReservar)

        btnReservar.setOnClickListener {
            val conductor = etConductor.text.toString()
            val horas = etHoras.text.toString().toInt()

            val intent = Intent(this, TicketActivity::class.java)
            intent.putExtra("DRIVER_NAME", conductor)
            intent.putExtra("PARK_HOURS", horas)
            startActivity(intent)
        }
    }
}