package com.example.autopark

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class TicketActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ticket)

        val tvConductor = findViewById<TextView>(R.id.tvConductor)
        val tvHoras = findViewById<TextView>(R.id.tvHoras)

        val conductor = intent.getStringExtra("conductor") ?: "Desconocido"
        val horas = intent.getIntExtra("horas", 0)

        tvConductor.text = "Conductor: $conductor"
        tvHoras.text = "Tiempo: $horas horas"
    }
}